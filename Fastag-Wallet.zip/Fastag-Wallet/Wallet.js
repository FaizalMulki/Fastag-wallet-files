﻿app.controller("WalletController", function ($scope, $http, $filter) {
    $scope.model = {};
  

    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    
    $scope.CheckVRN = function () {

        $scope.VehicleParams = {};
        $scope.VehicleParams.vrn = $scope.model.VehicleRegNo;
        $http({
            method: 'POST',
            url: baseUrl + 'WalletRecharge/CheckNumberIsValid',
            data: $scope.VehicleParams,
        }).then(function (response) {
            debugger;
            $scope.HideLoaderImg();

            //if (response.data == 'error') {
            //    SetMessage('Error')
            //}
            //else if (response.data == 'actDoesntExistOrBalanced') {
            //    SetMessage('ActDoesntExistOrBalaned')
            //}
            //else if (response.data == 'insuffiecient') {
            //    SetMessage('Insufficient')
            //}
            //else if (response.data == 'invalidaccount') {
            //    SetMessage('InvalidAccount')
            //}
            //else if (response.data == 'exceptionBal') {
            //    SetMessage('BalException')
            //}
            //else if (response.data == 'exceptionTrans') {
            //    SetMessage('TransException')
            //}
            //else {

            //    var Id = parseInt(response.data);
            //    $scope.submitFiles(Id);

            //    SetMessage("Save");

            //    window.location = "/Fastag/List";


            //}

        }, function errorCallback(response) {
            $scope.HideLoaderImg();
            SetMessage('Error');

        });


    }



    $scope.CheckCustomer = function () {

        $scope.VehicleParams = {};
        $scope.VehicleParams.vrn = $scope.model.VehicleRegNo;
        $http({
            method: 'POST',
            url: baseUrl + 'WalletRecharge/CheckFastagBalance',
            data: $scope.VehicleParams,
        }).then(function (response) {
            debugger;
            $scope.HideLoaderImg();

            //if (response.data == 'error') {
            //    SetMessage('Error')
            //}
            //else if (response.data == 'actDoesntExistOrBalanced') {
            //    SetMessage('ActDoesntExistOrBalaned')
            //}
            //else if (response.data == 'insuffiecient') {
            //    SetMessage('Insufficient')
            //}
            //else if (response.data == 'invalidaccount') {
            //    SetMessage('InvalidAccount')
            //}
            //else if (response.data == 'exceptionBal') {
            //    SetMessage('BalException')
            //}
            //else if (response.data == 'exceptionTrans') {
            //    SetMessage('TransException')
            //}
            //else {

            //    var Id = parseInt(response.data);
            //    $scope.submitFiles(Id);

            //    SetMessage("Save");

            //    window.location = "/Fastag/List";


            //}

        }, function errorCallback(response) {
            $scope.HideLoaderImg();
            SetMessage('Error');

        });


    }



    $scope.CheckBalance = function (e) {

        $scope.ShowLoaderImg();
        $http({
            method: 'POST',
            url: baseUrl + 'Fastag/CheckAccountBalance?Id=' + $scope.model.FromAccountNumber,

        }).then(function (response) {
            debugger;
            $scope.HideLoaderImg();
            alert(response.data);

        }, function errorCallback(response) {
            $scope.HideLoaderImg();


        });
    }


    $scope.Recharge = function () {      
        if ($scope.validator.validate()) {
            $scope.WalletRecharge = {};
            $scope.WalletRecharge.Id = $scope.model.Id;
            $scope.WalletRecharge.VehicleRegNo=$scope.model.VehicleRegNo;
            $scope.WalletRecharge.Amount = $scope.model.Amount;
            $scope.WalletRecharge.FromAccountNumber = $scope.model.FromAccountNumber;
            $scope.WalletRecharge.ToAccountNumber = $scope.model.ToAccountNumber;
            $scope.WalletRecharge.PaymentType=$scope.model.PaymentType;
            $http({
                method: 'POST',
                url: baseUrl + 'WalletRecharge/RechargeWallet',
                data: $scope.WalletRecharge,
            }).then(function (response) {

                debugger;
                $scope.HideLoaderImg();

                //        if (response.data == 'error') {
                //            SetMessage('Error')
                //        }
                //        else if (response.data == 'actDoesntExistOrBalanced') {
                //            SetMessage('ActDoesntExistOrBalaned')
                //        }
                //        else if (response.data == 'insuffiecient') {
                //            SetMessage('Insufficient')
                //        }
                //        else if (response.data == 'invalidaccount') {
                //            SetMessage('InvalidAccount')
                //        }
                //        else if (response.data == 'exceptionBal') {
                //            SetMessage('BalException')
                //        }
                //        else if (response.data == 'exceptionTrans') {
                //            SetMessage('TransException')
                //        }
                //        else {

                //            var Id = parseInt(response.data);
                //            $scope.submitFiles(Id);

                //            SetMessage("Save");

                //            window.location = "/Fastag/List";


                //        }

                //    }, function errorCallback(response) {
                //        $scope.HideLoaderImg();
                //        SetMessage('Error');

                //    });
                //}
                //else {
                //    SetMessage('NoData');
                //}
            });
            }
    }



    $scope.Registration = function (e) {
        window.location = "/Fastag/Registration";
    }
    $scope.Edit=function(e)
    {
        
        var Id=e.dataItem.Id;
        window.location = "/Fastag/Edit?Id=" + Id;
    }
   


   

});